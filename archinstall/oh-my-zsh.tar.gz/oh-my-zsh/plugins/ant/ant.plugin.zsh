# Default to colored output
export ANT_ARGS='-logger org.apache.tools.ant.listener.AnsiColorLogger'
